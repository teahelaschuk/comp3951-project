﻿/**************************************************************************\
    Copyright Microsoft Corporation. All Rights Reserved.
\**************************************************************************/

namespace Microsoft.Windows.Shell
{
    public class JumpPath : JumpItem
    {
        public JumpPath()
        {}

        public string Path { get; set; }
    }
}
